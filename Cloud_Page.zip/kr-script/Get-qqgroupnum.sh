#!/bin/bash
number_regex='^[0-9]+$'
url_regex='^(http|https)://.*$'

if echo "$QQlink" | grep -qE "$number_regex"; then
  	am start -d "mqqapi://card/show_pslcard?uin=$QQlink&card_type=group" >/dev/null 2>&1
elif echo "$QQlink" | grep -qE "$url_regex"; then
	response=$(curl -sL "$QQlink")
	rawuin=$(echo "$response" | grep -o 'var rawuin =  [0-9]*' | awk '{print $4}')
	echo "该链接指向的QQ群号为: $rawuin"
	am start -d "mqqapi://card/show_pslcard?uin=$rawuin&card_type=group" >/dev/null 2>&1
else
  echo "？你输错了吧"
fi
