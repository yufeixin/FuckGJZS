if [[ $Enable = 1 ]]; then
    settings put global captive_portal_mode 1
    case $captive_server in
    0)
        settings delete global captive_portal_http_url
        settings delete global captive_portal_https_url
    ;;
    
    1)
        settings put global captive_portal_http_url http://www.qualcomm.cn/generate_204
        settings put global captive_portal_https_url https://www.qualcomm.cn/generate_204
    ;;
    esac
    if [[ $HTTPS = 1 ]]; then
        settings put global captive_portal_use_https 1
    else
        settings put global captive_portal_use_https 0
    fi
else
    settings put global captive_portal_mode 0
fi
settings put global airplane_mode_on 1
sleep 1
settings put global airplane_mode_on 0