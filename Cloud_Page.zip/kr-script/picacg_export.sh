#!/bin/bash

# Setup directories
OUTPUT_DIR="$GJZS/img_Extract"
TEMP_DIR="$GJZS/temp_picacomic_extract"
DB_PATH="$DATA_DIR/com.picacomic.fregata/databases/com_picacomic_fregata.db"

# Create directories and cleanup
mkdir -p "$OUTPUT_DIR" "$TEMP_DIR"
rm -rf "$TEMP_DIR"/*

# Check database existence
[ ! -f "$DB_PATH" ] && { echo "错误: 找不到数据库 $DB_PATH"; exit 1; }

# Find episode directories
EPISODE_DIRS=$(find "$SD_PATH/Android/data/com.picacomic.fregata/files/" -mindepth 1 -maxdepth 1 -type d)
[ -z "$EPISODE_DIRS" ] && { echo "错误: 找不到分集目录"; exit 1; }

# Helper function to sanitize filenames (preserves spaces)
sanitize_filename() {
    echo "$1" | tr '/:*?"<>|' '_________'
}

# Process each episode directory
for EPISODE_DIR in $EPISODE_DIRS; do
    EPISODE_ID=$(basename "$EPISODE_DIR")
    
    # Get comic ID and episode title
    COMIC_INFO=$(sqlite3 "$DB_PATH" "SELECT COMIC_ID, TITLE FROM DOWNLOAD_COMIC_EPISODE_OBJECT WHERE EPISODE_ID='$EPISODE_ID'")
    [ -z "$COMIC_INFO" ] && { echo "错误: 找不到 $EPISODE_ID 的漫画信息，跳过..."; continue; }
    
    COMIC_ID=$(echo "$COMIC_INFO" | cut -d'|' -f1)
    EPISODE_TITLE=$(sanitize_filename "$(echo "$COMIC_INFO" | cut -d'|' -f2)")
    
    # Get comic author and title
    COMIC_DETAILS=$(sqlite3 "$DB_PATH" "SELECT AUTHOR, TITLE FROM DB_COMIC_DETAIL_OBJECT WHERE COMIC_ID='$COMIC_ID'")
    if [ -z "$COMIC_DETAILS" ]; then
        COMIC_AUTHOR="Unknown"
        COMIC_TITLE="Comic_$COMIC_ID"
    else
        COMIC_AUTHOR=$(sanitize_filename "$(echo "$COMIC_DETAILS" | cut -d'|' -f1)")
        COMIC_TITLE=$(sanitize_filename "$(echo "$COMIC_DETAILS" | cut -d'|' -f2)")
    fi
    
    # Create directory structure
    COMIC_FOLDER="$COMIC_AUTHOR - $COMIC_TITLE"
    COMIC_DIR="$TEMP_DIR/$COMIC_FOLDER"
    EPISODE_OUTPUT_DIR="$COMIC_DIR/$EPISODE_TITLE"
    mkdir -p "$EPISODE_OUTPUT_DIR"
    
    echo "正在导出: $COMIC_AUTHOR - $COMIC_TITLE"
    
    # Save metadata
    cat > "$COMIC_DIR/info.txt" << EOF
原始作者: $COMIC_AUTHOR
原始标题: $COMIC_TITLE
COMIC_ID: $COMIC_ID
EPISODE_ID: $EPISODE_ID
EOF
    
    # Get image information
    IMAGE_INFO=$(sqlite3 "$DB_PATH" "SELECT MEDIA_PATH, MEDIA_ORIGINAL_NAME FROM DOWNLOAD_COMIC_PAGE_OBJECT WHERE EPISODE_ID='$EPISODE_ID'")
    [ -z "$IMAGE_INFO" ] && { echo "错误: 找不到 $EPISODE_ID 的图片信息，跳过..."; continue; }
    
    # Process each image
    echo "$IMAGE_INFO" | while IFS='|' read -r MEDIA_PATH MEDIA_ORIGINAL_NAME; do
        [ -z "$MEDIA_PATH" ] || [ -z "$MEDIA_ORIGINAL_NAME" ] && continue
        
        # Handle file extension
        FILE_EXT="${MEDIA_PATH##*.}"
        SOURCE_FILE="$EPISODE_DIR/$MEDIA_PATH"
        [ ! -f "$SOURCE_FILE" ] && { echo "错误: 文件不存在: $SOURCE_FILE"; continue; }
        
        # Set destination filename with proper extension
        [[ "$MEDIA_ORIGINAL_NAME" != *.$FILE_EXT ]] && DEST_FILENAME="$MEDIA_ORIGINAL_NAME.$FILE_EXT" || DEST_FILENAME="$MEDIA_ORIGINAL_NAME"
        
        # Copy file
        cp "$SOURCE_FILE" "$EPISODE_OUTPUT_DIR/$DEST_FILENAME" 2>/dev/null || {
            echo "错误: 复制失败: $SOURCE_FILE"
            mkdir -p "$EPISODE_OUTPUT_DIR" 
            cp "$SOURCE_FILE" "$EPISODE_OUTPUT_DIR/$DEST_FILENAME" 2>/dev/null || echo "错误: 重试失败: $SOURCE_FILE"
        }
    done
done

# Create zip archives for each comic
find "$TEMP_DIR" -mindepth 1 -maxdepth 1 -type d | while read -r COMIC_DIR; do
    COMIC_NAME=$(basename "$COMIC_DIR")
    ZIP_FILE="$OUTPUT_DIR/$COMIC_NAME.zip"
    
    echo "正在压缩: $COMIC_NAME"
    
    # Try to create zip file
    (cd "$TEMP_DIR" && zip -rq "$ZIP_FILE" "$COMIC_NAME") || {
        echo "错误: 创建 \"$COMIC_NAME.zip\" 失败"
        (cd "$COMIC_DIR/.." && zip -rq "$ZIP_FILE" "$COMIC_NAME") || echo "错误: 替代方法也失败，无法创建 \"$COMIC_NAME.zip\""
    }
done

# Clean up and finish
rm -rf "$TEMP_DIR"
echo "提取完成, 所有漫画已处理并保存到 $OUTPUT_DIR, 你可以在 哔咔漫画 里删除下载的文件"