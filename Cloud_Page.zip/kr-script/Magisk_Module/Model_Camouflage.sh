#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


mask -vc
mask $1
data=`date '+%F'`
model2=`getprop ro.product.model`
device2=`getprop ro.product.device`
brand2=`getprop ro.product.brand`
version2=`getprop ro.build.version.incremental`


JiXing() {
echo -e "已选择伪装成$2"
cat <<Han >$Module/system.prop
ro.product.model=$1
ro.product.name=$2
ro.product.device=$2
ro.product.board=$2
ro.product.brand=$3
ro.product.manufacturer=$3
ro.product.system.model=$1
ro.product.system.name=$2
ro.product.system.device=$2
ro.product.system.board=$2
ro.product.system.brand=$3
ro.product.system.manufacturer=$3
ro.product.vendor.model=$1
ro.product.vendor.name=$2
ro.product.vendor.device=$2
ro.product.vendor.board=$2
ro.product.vendor.brand=$3
ro.product.vendor.manufacturer=$3
Han

printf "id=Model_Camouflage
name=机型伪装
version=114514
versionCode=$Time
author=People11
description=伪装手机型号为：$2" >$Module_XinXi
}

prop() {
cat <<Han >$Module/system.prop
ro.product.model=${model:=$model2}
ro.product.name=${device:=$device2}
ro.product.device=${device:=$device2}
ro.product.board=${device:=$device2}
ro.product.brand=${brand:=$brand2}
ro.product.manufacturer=${brand:=$brand2}
ro.product.system.model=${model:=$model2}
ro.product.system.name=${device:=$device2}
ro.product.system.device=${device:=$device2}
ro.product.system.board=${device:=$device2}
ro.product.system.brand=${brand:=$brand2}
ro.product.system.manufacturer=${brand:=$brand2}
ro.product.vendor.model=${model:=$model2}
ro.product.vendor.name=${device:=$device2}
ro.product.vendor.device=${device:=$device2}
ro.product.vendor.board=${device:=$device2}
ro.product.vendor.brand=${brand:=$brand2}
ro.product.vendor.manufacturer=${brand:=$brand2}
ro.build.version.incremental=${version:=$version2}
ro.system.build.version.incremental=${version:=$version2}
Han
}

module_prop() {
cat <<Han >$Module_XinXi
id=Model_Camouflage
name=机型伪装
version=$Time
versionCode=114514
author=People11
description=自定义伪装手机型号：$model、 品牌：$brand、 代号：$device、 版本号：$version
Han
}

[[ ! -d $Module ]] && mkdir -p $Module

case $Device in
    MI12P)
        JiXing "2201122C" "zeus" "Xiaomi"
    ;;

    MIMIXF)
        JiXing "M2011J18C" "cetus" "Xiaomi"
    ;;

    MIMIX4)
        JiXing "2106118C" "odin" "Xiaomi"
    ;;

    RMIK50P)
        JiXing "22011211C" "matisse" "Xiaomi"
    ;;

    RMIK50G)
        JiXing "21121210C" "ingres" "Xiaomi"
    ;;

    RMIN11PP)
        JiXing "21091116UC" "pissarropro" "Xiaomi"
    ;;

    HWP50P)
        JiXing "JAD-AL50" "jade" "HUAWEI"
    ;;

    HWP50PK)
        JiXing "BAL-AL10" "HWBAL" "HUAWEI"
    ;;

    HWM50P)
        JiXing "DCO-AL00" "HWDCO" "HUAWEI"
    ;;

    HWMX2)
        JiXing "TET-AN00" "teton" "HUAWEI"
    ;;

    HWMXS)
        JiXing "TAH-AN00m" "tahiti" "HUAWEI"
    ;;

    HWMPP11)
        JiXing "GOT-AL19" "Goethe" "HUAWEI"
    ;;

    IQ10P)
        JiXing "V2218A" "PD2218" "vivo"
    ;;

    IQ9P)
        JiXing "V2172A" "PD2172" "vivo"
    ;;

    SHARK5P)
        JiXing "SHARK KTUS-A0" "katyusha" "Xiaomi"
    ;;

    OPACEP)
        JiXing "PGP110" "ovaltine" "OnePlus"
    ;;

    OP10P)
        JiXing "NE2210" "negroni" "OnePlus"
    ;;

    MZ18P)
        JiXing "M191Q" "m2191" "Meizu"
    ;;

    STSR2)
        JiXing "DT2002C" "darwin" "Smartisan"
    ;;

    STST2)
        JiXing "SM801" "icesky" "Smartisan"
    ;;

    LNVY90)
        JiXing "Lenovo L71061" "diablo" "Lenovo"
    ;;

    LNVY70)
        JiXing "Lenovo L71091" "halo" "Lenovo"
    ;;
    
    APP14PM)
        JiXing "A2896" "iPhone15,3" "Apple"
    ;;

    APPIPP129)
        JiXing "A2462" "iPad13,11" "Apple"
    ;;

    APPIPA5)
        JiXing "A2591" "iPad13,17" "Apple"
    ;;

    APPIPM6)
        JiXing "A2569" "iPad14,2" "Apple"
    ;;

    APPSE3)
        JiXing "A2785" "iPhone14,6" "Apple"
    ;;

    SAMS22U)
        JiXing "SM-S9080" "b0q" "Samsung"
    ;;

    SAMS21P)
        JiXing "SM-G9960" "t2q" "Samsung"
    ;;

    SAMS21)
        JiXing "SM-G9910" "o1q" "Samsung"
    ;;

    SAMN20U)
        JiXing "SM-N9860" "c2q" "Samsung"
    ;;

    SAMZF2)
        JiXing "SM-F9160" "f2q" "Samsung"
    ;;

    SAMZFL5G)
        JiXing "SM-F7070" "bloomxq" "Samsung"
    ;;

    GGP6P)
        JiXing "Pixel 6 Pro" "raven" "Google"
    ;;

    GGPC)
        JiXing "Pixel C" "dragon" "Google"
    ;;

    WSA)
        JiXing "Subsystem for Android(TM)" "windows_x86_64" "Windows"
    ;;
    
    SNXPP1)
        JiXing "XQ-BE72" "lahaina" "Sony"
    ;;

    Customize)
    prop >$Module/system.prop
    module_prop >$Module_XinXi
    ;;
esac

    [[ -f $Module/system.prop ]] && echo "机型伪装模块创建完成，模块将在下次重启时生效" && CQ
