Customize|自定义
MI12P|小米 12 Pro
MIMIXF|小米 MIX Fold
MIMIX4|小米 MIX 4
RMIK50P|红米 K50 Pro
RMIK50G|红米 K50 电竞版
RMIN11PP|红米 Note 11 Pro +
HWP50P|华为 P50 Pro
HWP50PK|华为 P50 Pocket
HWM50P|华为 Mate 50 Pro
HWMX2|华为 Mate X2
HWMXS|华为 Mate XS
HWMPP11|华为 MatePad Pro 11
IQ10P|IQOO 10 Pro
IQ9P|IQOO 9 Pro
SHARK5P|黑鲨 5 Pro
OPACEP|一加 Ace Pro
OP10P|一加 10 Pro
MZ18P|魅族 18 Pro
STSR2|坚果 R2
STST2|锤子 T2
LNVY90|联想拯救者 Y90
LNVY70|联想拯救者 Y70
APP14PM|苹果 iPhone 14 Pro Max
APPIPP129|苹果 iPad Pro 12.9英寸 第5代
APPIPA5|苹果 iPad Air 5
APPIPM6|苹果 iPad mini 6
APPSE3|苹果 iPhone SE 3
SAMS22U|三星 Galaxy S22 Ultra
SAMN20U|三星 Galaxy Note 20 Ultra
SAMZF2|三星 Galaxy Z Fold2
SAMZFL5G|三星 Galaxy Z Flip 5G
GGP6P|Google Pixel 6 Pro
GGPC|Google Pixel C
WSA|适用于 Android™️ 的 Windows 子系统
SNXPP1|Sony Xperia PRO-I