mask -vc
mask $1

[[ -d $Module ]] && rm -rf $Module
echo "正在移除温控"

[[ $VendorJson = 1 ]] && {
    for b in `find "/vendor" -name "*thermal*.json" -o -name "*thermal*.conf" -type f`; do
        echo "$b" | fgrep -iq 'android.' && continue
        echo - $b
        mktouch "$Module/system/$b"
    done
}

[[ $VendorEX = 1 ]] && {
    for c in `find "/vendor" -name "*thermal*" ! -name "*thermal*.json" ! -name "*thermal*.conf" -type f`; do
        echo "$c" | fgrep -iq 'android.' && continue
        echo "$c" | fgrep -iq 'lib64' && continue
        echo - $c
        mktouch "$Module/system/$c"
    done
}

[[ $Perf = 1 ]] && {
    for d in `find "/vendor/etc/perf" -name "*.xml" -type f`; do
        echo "$d" | fgrep -iq 'android.' && continue
        echo - $d
        mktouch "$Module/system/$d"
    done
    for e in `find "/vendor/etc/perf" -name "perf*" -type f`; do
        echo "$e" | fgrep -iq 'android.' && continue
        echo - $e
        mktouch "$Module/system/$e"
    done
    for f in `find "/vendor/etc/perf" -name "*conf" -type f`; do
        echo "$f" | fgrep -iq 'android.' && continue
        echo - $f
        mktouch "$Module/system/$f"
    done
}

[[ $MIUICloudThermal = 1 ]] && {
    for g in `find "/data/thermal/." -type f`; do
        sed -i '/trig/d;/clr/d;/target/d' "$g"
    done
    for h in `find "/data/vendor/thermal/." -type f`; do
        sed -i '/trig/d;/clr/d;/target/d' "$h"
    done
    /data/adb/magisk/busybox chattr +i /data/thermal/
    /data/adb/magisk/busybox chattr +i /data/vendor/thermal/
}

mktouch "$Module/uninstall.sh"
echo "/data/adb/magisk/busybox chattr -i /data/thermal/" >> "$Module/uninstall.sh"
echo "/data/adb/magisk/busybox chattr -i /data/vendor/thermal/" >> "$Module/uninstall.sh"

. $Load $1
module_prop
[[ -f $Module_XinXi ]] && echo -e "\n- 「$name」模块已创建" && CQ
