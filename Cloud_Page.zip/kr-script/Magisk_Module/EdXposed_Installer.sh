#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


ChongQi2=$ChongQi
ChongQi=0
Choice=1

if [[ $SELinux_OFF = 1 ]]; then
    sh $install_MOD $Compatible $Error None 1 "SELinux_OFF"
fi

    mask riru-core
    if [[ -d "$Module" ]]; then
        echo "- 已安装Riru （Riru - Core）$version($versionCode)"
        [[ 0 -eq $Riru_version && 426 -lt $versionCode || 41 -gt $versionCode ]] && echo "已安装的Riru （Riru - Core）版本在V22以下或V25以上，已自动打开安装Riru开关" && Riru_version=1
    else
        echo "你还没有安装Riru （Riru - Core），已自动打开安装Riru开关" && Riru_version=1
    fi

        [[ $Riru_version = 1 ]] && . ./Magisk_Module/Riru_Installer.sh $Riru_version
        if [[ -d $DATA_DIR/com.solohsu.android.edxp.manager ]]; then abort -e "作者已弃坑EDXposed Installer，请卸载并安装EDXposed Manager"; fi
            [[ -f /system/lib/libjit.so ]] && abort "一山不容二虎，请先卸载太极 · 阳模块，再来安装EDXposed吧！"
            [[ -d $Modules_Dir/riru_lsposed ]] && echo "已安装Riru - LSPosed，已自动禁用" && touch $Modules_Dir/riru_lsposed/disable
            [[ -d $Modules_Dir/riru_dreamland ]] && echo "已安装Riru-Dreamland，已自动禁用" && touch $Modules_Dir/riru_dreamland/disable
            echo -e "- 卸载可能已经安装的\n$Modules_Dir/riru_edxposed\n$Modules_Dir/riru_edxposed_sandhook\n避免部分人同时安装两个EDXposed框架"
            sleep 1
            sh $Modules_Dir/riru_edxposed/uninstall.sh &>/dev/null
            sh $Modules_Dir/riru_edxposed_sandhook/uninstall.sh &>/dev/null
            rm -rf $Modules_Dir/riru_edxposed $Modules_Dir/riru_edxposed_sandhook
            . $Load riru_edxposed
            ZIPFILE="$Download_File"
            if [[ -f "$ZIPFILE" ]]; then
                echo "---------------------------------------------------------"
                sh $install_MOD $Compatible $Error "$ZIPFILE" 0
            else
                abort "文件不存在安装失败"
            fi
                sleep 1
                ChongQi=$ChongQi2
                CQ
    