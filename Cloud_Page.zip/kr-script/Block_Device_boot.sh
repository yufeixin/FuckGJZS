#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


sh ./Block_Device_Name.sh | grep '/boot'
