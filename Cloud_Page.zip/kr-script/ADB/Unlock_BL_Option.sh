fastboot oem unlook-go; fastboot oem unlook|fastboot oem unlook
fastboot oem unlook-go
fastboot flashing unlock
fastboot flashing unlock_critical
fastboot bbk unlock_vivo
